import java.util.Scanner;
public class good{
	public static void main(String[] args){
		int a,b,c;
		Scanner sc=new Scanner(System.in);
		a=sc.nextInt();
		b=sc.nextInt();
		c=sc.nextInt();
		System.out.println("the first number you have typed is: "+a);
		System.out.println("the second number you have typed is: "+b);
		System.out.println("the thied number you habe types is "+c);
		
	}
}